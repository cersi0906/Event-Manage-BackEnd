<?php
$servername = "localhost";       // default for phpMyAdmin
$username = "root";              // default user in XAMPP/WAMP
$password = "";                  // empty password by default
$database = "eventmanagementsystem";            // your database name

// Connect to database
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";
?>
