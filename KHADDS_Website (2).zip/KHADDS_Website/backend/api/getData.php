<?php
include_once '../includes/connect.php';
header('Content-Type: application/json');

$sql = "SELECT * FROM your_table"; // replace with your actual table
$result = $conn->query($sql);
$data = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

echo json_encode($data);
?>
