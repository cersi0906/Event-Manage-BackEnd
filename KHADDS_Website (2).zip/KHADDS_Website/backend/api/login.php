<?php
echo "<h3>🧠 Debug from PHP</h3>";
echo "<pre>";
print_r($_POST);
echo "</pre>";
?>

<?php
include '../../connect.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

$mode = $_POST['mode'] ?? '';
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';
$email = $_POST['email'] ?? '';
$lname = '';
$phone = '';

if ($mode === "login") {
    echo "<h3>LOGIN MODE</h3>";
    echo "Looking for: $username / $password";

    $sql = "SELECT * FROM Users WHERE User_ID = ? AND Password = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ss", $username, $password);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) > 0) {
        echo "Login successful!";
    } else {
        echo "Invalid username or password.";
    }

} elseif ($mode === "register") {
    echo "<h3>REGISTER MODE</h3>";
    $sql = "INSERT INTO Users (User_ID, FName, LName, Email, Password, Phone)
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ssssss", $username, $username, $lname, $email, $password, $phone);

    if (mysqli_stmt_execute($stmt)) {
        echo "Account created successfully!";
    } else {
        echo "Error: " . mysqli_error($conn);
    }

} else {
    echo "Invalid mode. Must be 'login' or 'register'.";
}
?>
