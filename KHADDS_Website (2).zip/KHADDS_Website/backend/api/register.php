<?php
include '../../connect.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

$userId = $_POST['username'] ?? '';
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

// Optional
$lname = '';
$phone = '';
$fname = $userId; // treating entered username as first name

// Debug
echo "<h3>DEBUG: Register Request</h3>";
echo "<pre>";
print_r($_POST);
if (empty($_POST)) {
    echo "❌ No form data received — check your frontend!";
    exit;
}
echo "</pre>";

$sql = "INSERT INTO Users (User_ID, FName, LName, Email, Password, Phone)
        VALUES (?, ?, ?, ?, ?, ?)";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ssssss", $userId, $fname, $lname, $email, $password, $phone);

if (mysqli_stmt_execute($stmt)) {
    echo "Account created successfully!";
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
