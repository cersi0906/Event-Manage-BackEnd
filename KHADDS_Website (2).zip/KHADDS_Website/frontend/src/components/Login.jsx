import React, { useState } from "react";

const Login = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: ""
  });

  const [message, setMessage] = useState("");
  const [messageType, setMessageType] = useState("");

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const { username, email, password } = formData;

    if (!username || !password || (!isLogin && !email)) {
      setMessage("Please fill in all required fields.");
      setMessageType("error");
      return;
    }

    if (isLogin) {
      if (username === "admin" && password === "12345") {
        setMessage("Login successful!");
        setMessageType("success");
      } else {
        setMessage("Invalid username or password.");
        setMessageType("error");
      }
    } else {
      setMessage("Account created successfully!");
      setMessageType("success");
    }
  };

  return (
    <div
      style={{
        width: "100%",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        minHeight: "80vh"
      }}
    >
      <form onSubmit={handleSubmit} className="wide-form">
        <h2 style={{ textAlign: "center", marginBottom: "25px" }}>
          {isLogin ? "Login" : "Create Account"}
        </h2>

        <div style={{ marginBottom: "20px" }}>
          <label>Username:</label>
          <input
            type="text"
            name="username"
            value={formData.username}
            onChange={handleChange}
            style={{ width: "100%", padding: "10px", borderRadius: "6px", border: "1px solid #ccc" }}
          />
        </div>

        {!isLogin && (
          <div style={{ marginBottom: "20px" }}>
            <label>Email:</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              style={{ width: "100%", padding: "10px", borderRadius: "6px", border: "1px solid #ccc" }}
            />
          </div>
        )}

        <div style={{ marginBottom: "20px" }}>
          <label>Password:</label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            style={{ width: "100%", padding: "10px", borderRadius: "6px", border: "1px solid #ccc" }}
          />
        </div>

        <button
          type="submit"
          style={{
            width: "100%",
            padding: "12px",
            backgroundColor: isLogin ? "#007bff" : "#28a745",
            color: "white",
            border: "none",
            borderRadius: "6px",
            fontSize: "16px",
            cursor: "pointer"
          }}
        >
          {isLogin ? "Login" : "Create Account"}
        </button>

        {message && (
          <div
            style={{
              color: messageType === "error" ? "red" : "green",
              textAlign: "center",
              marginTop: "15px"
            }}
          >
            {message}
          </div>
        )}

        <p style={{ marginTop: "15px", textAlign: "center" }}>
          {isLogin ? (
            <>
              Don’t have an account?{" "}
              <span
                onClick={() => setIsLogin(false)}
                style={{ color: "blue", cursor: "pointer", textDecoration: "underline" }}
              >
                Create one
              </span>
            </>
          ) : (
            <>
              Already have an account?{" "}
              <span
                onClick={() => setIsLogin(true)}
                style={{ color: "blue", cursor: "pointer", textDecoration: "underline" }}
              >
                Login
              </span>
            </>
          )}
        </p>
      </form>
    </div>
  );
};

export default Login;
