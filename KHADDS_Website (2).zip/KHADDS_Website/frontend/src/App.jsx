import './App.css';
import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import RegisterForm from "./components/RegisterForm";
import Login from "./components/Login";
import Session from "./components/Session";
import Events from "./components/Events";
import Tickets from "./components/Tickets"; // ✅ New import

function App() {
  return (
    <Router>
      <header className="header">
        <h1>Event Management System</h1>
        <nav className="nav-tabs">
          <Link to="/login">Login</Link>
          <Link to="/events">Events</Link>
          <Link to="/session">Session</Link>
          
          <Link to="/tickets">Tickets</Link> {/* ✅ New link */}
          <Link to="/feedback">Feedback</Link>
        </nav>
      </header>

      <div className="form-wrapper">
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/session" element={<Session />} />
          <Route path="/events" element={<Events />} />
          <Route path="/tickets" element={<Tickets />} /> {/* ✅ New route */}
          <Route path="/register" element={<RegisterForm />} />
          
          {/* Add Feedback and Confirmation routes when ready */}
        </Routes>
      </div>
    </Router>
  );
}

export default App;
