// src/components/Create.jsx

import React, { useState } from "react";

const Create = ({ onSwitchToLogin }) => {
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: ""
  });

  const [message, setMessage] = useState("");
  const [messageType, setMessageType] = useState("");

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!formData.username || !formData.email || !formData.password) {
      setMessage("Please fill out all fields.");
      setMessageType("error");
      return;
    }

    // Simulate successful registration
    setMessage("Account created successfully!");
    setMessageType("success");
    // Optionally: auto-switch back to login
    // setTimeout(onSwitchToLogin, 1500);
  };

  return (
    <form onSubmit={handleSubmit} style={{ maxWidth: "400px", margin: "0 auto" }}>
      <h2 style={{ textAlign: "center", marginBottom: "25px" }}>Create Account</h2>

      <div style={{ marginBottom: "20px" }}>
        <label>Username:</label>
        <input
          type="text"
          name="username"
          value={formData.username}
          onChange={handleChange}
          style={{ width: "100%", padding: "10px", borderRadius: "6px", border: "1px solid #ccc" }}
        />
      </div>

      <div style={{ marginBottom: "20px" }}>
        <label>Email:</label>
        <input
          type="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          style={{ width: "100%", padding: "10px", borderRadius: "6px", border: "1px solid #ccc" }}
        />
      </div>

      <div style={{ marginBottom: "20px" }}>
        <label>Password:</label>
        <input
          type="password"
          name="password"
          value={formData.password}
          onChange={handleChange}
          style={{ width: "100%", padding: "10px", borderRadius: "6px", border: "1px solid #ccc" }}
        />
      </div>

      <button
        type="submit"
        style={{
          width: "100%",
          padding: "12px",
          backgroundColor: "#28a745",
          color: "white",
          border: "none",
          borderRadius: "6px",
          fontSize: "16px",
          cursor: "pointer"
        }}
      >
        Create Account
      </button>

      {message && (
        <div
          style={{
            color: messageType === "error" ? "red" : "green",
            textAlign: "center",
            marginTop: "15px"
          }}
        >
          {message}
        </div>
      )}

      <p style={{ marginTop: "15px", textAlign: "center" }}>
        Already have an account?{" "}
        <span
          onClick={onSwitchToLogin}
          style={{ color: "blue", cursor: "pointer", textDecoration: "underline" }}
        >
          Login
        </span>
      </p>
    </form>
  );
};

export default Create;
