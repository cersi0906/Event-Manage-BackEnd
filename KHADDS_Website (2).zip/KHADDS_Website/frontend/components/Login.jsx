import React, { useState } from "react";

const Login = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    username: "",
    password: "",
    email: ""
  });

  const [message, setMessage] = useState("");
  const [messageType, setMessageType] = useState("");

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData((prev) => ({ ...prev, [id]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { username, password, email } = formData;

    if (!username || !password || (!isLogin && !email)) {
      setMessage("Please fill in all required fields.");
      setMessageType("error");
      return;
    }

    const formDataToSend = new FormData();
    formDataToSend.append("username", username);
    formDataToSend.append("password", password);
    formDataToSend.append("mode", isLogin ? "login" : "register");
    if (!isLogin) {
      formDataToSend.append("email", email);
    }

    // ✅ Debug all data being sent
    console.log("🔍 Sending form to PHP:");
    for (const pair of formDataToSend.entries()) {
      console.log(`${pair[0]}: ${pair[1]}`);
    }

    try {
      const response = await fetch("http://localhost/KHADDS_Website/backend/api/login.php", {
        method: "POST",
        body: formDataToSend
      });

      const result = await response.text();
      console.log("🐘 PHP Response:", result);
      setMessage(result);
      setMessageType(result.toLowerCase().includes("success") ? "success" : "error");
    } catch (error) {
      console.error("❌ Error sending request:", error);
      setMessage("Something went wrong.");
      setMessageType("error");
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{ maxWidth: "400px", margin: "0 auto" }}>
      <h2 style={{ textAlign: "center", marginBottom: "25px" }}>
        {isLogin ? "Login" : "Create Account"}
      </h2>

      <div style={{ marginBottom: "20px" }}>
        <label htmlFor="username">Username:</label>
        <input
          type="text"
          id="username"
          value={formData.username}
          onChange={handleChange}
          style={{ width: "100%", padding: "10px", borderRadius: "6px", border: "1px solid #ccc" }}
        />
      </div>

      {!isLogin && (
        <div style={{ marginBottom: "20px" }}>
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            value={formData.email}
            onChange={handleChange}
            style={{ width: "100%", padding: "10px", borderRadius: "6px", border: "1px solid #ccc" }}
          />
        </div>
      )}

      <div style={{ marginBottom: "20px" }}>
        <label htmlFor="password">Password:</label>
        <input
          type="password"
          id="password"
          value={formData.password}
          onChange={handleChange}
          style={{ width: "100%", padding: "10px", borderRadius: "6px", border: "1px solid #ccc" }}
        />
      </div>

      <button
        type="submit"
        style={{
          width: "100%",
          padding: "12px",
          backgroundColor: "#007bff",
          color: "white",
          border: "none",
          borderRadius: "6px",
          fontSize: "16px",
          cursor: "pointer"
        }}
      >
        {isLogin ? "Login" : "Create Account"}
      </button>

      {message && (
        <div
          style={{
            color: messageType === "error" ? "red" : "green",
            textAlign: "center",
            marginTop: "15px"
          }}
        >
          {message}
        </div>
      )}

      <p style={{ marginTop: "15px", textAlign: "center" }}>
        {isLogin ? "Don’t have an account?" : "Already have an account?"}{" "}
        <span
          onClick={() => setIsLogin(!isLogin)}
          style={{ color: "blue", cursor: "pointer", textDecoration: "underline" }}
        >
          {isLogin ? "Create one" : "Log in"}
        </span>
      </p>
    </form>
  );
};

export default Login;
