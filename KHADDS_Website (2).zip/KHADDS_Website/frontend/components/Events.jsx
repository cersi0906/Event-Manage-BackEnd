// src/components/Events.jsx
import React from "react";

const events = [
  {
    id: 1,
    name: "Tech Summit 2025",
    date: "07/02/2025",
    location: "New York City, NY",
    description: "Annual technology summit with keynotes and panels."
  },
  {
    id: 2,
    name: "Women in Computing Conference",
    date: "08/10/2025",
    location: "San Francisco, CA",
    description: "Celebrating women in tech with networking and talks."
  },
  {
    id: 3,
    name: "Cybersecurity Awareness Workshop",
    date: "09/18/2025",
    location: "Charlotte, NC",
    description: "A hands-on event teaching students basic cybersecurity practices.",
  },
  {
    id: 4,
    name: "Hackathon Code for Good",
    date: "10/02/2025",
    location: "Norfolk, VA",
    description: "A 24-hour coding challenge focused on solving social issues.",
  },
  {
    id: 5,
    name: "Resume & LinkedIn Workshop",
    date: "11/13/2025",
    location: "Dallas, TX",
    description: "Tips and feedback on building your online professional brand.",
  },
  {
    id: 6,
    name: "Internship Prep Workshop",
    date: "12/5/2025",
    location: "Atlanta, GA",
    description: "Learn how to find, apply for, and succeed in internships.",
  },
  {
    id: 7,
    name: "JavaScript Crash Course",
    date: "12/17/2025",
    location: "Washington D.C.",
    description: "A beginner-friendly coding class with real project examples.",
  }
];

const Events = () => {
  return (
    <div style={{ padding: "30px" }}>
      <h2 style={{ textAlign: "center", marginBottom: "25px" }}>Upcoming Events</h2>
      {events.map(event => (
        <div key={event.id} style={{
          marginBottom: "20px",
          border: "1px solid #ccc",
          borderRadius: "8px",
          padding: "15px",
          boxShadow: "0 2px 4px rgba(0,0,0,0.05)"
        }}>
          <h3>{event.name}</h3>
          <p><strong>Date:</strong> {event.date}</p>
          <p><strong>Location:</strong> {event.location}</p>
          <p>{event.description}</p>
        </div>
      ))}
    </div>
  );
};

export default Events;
