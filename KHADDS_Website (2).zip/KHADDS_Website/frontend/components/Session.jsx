import React from "react";

const sessions = [
  {
    id: 1,
    title: "Cybersecurity in the Age of AI",
    speaker: "Dr. Janet Williams",
    time: "10:00 AM - 11:00 AM",
    location: "Room A101"
  },
  {
    id: 2,
    title: "Building Scalable Web Apps",
    speaker: "Daniel Ufua",
    time: "11:30 AM - 12:30 PM",
    location: "Room B203"
  },
  {
    id: 3,
    title: "Zero Trust Networks Explained",
    speaker: "Alex Rivera",
    time: "1:00 PM - 2:00 PM",
    location: "Room C301"
  }
];

const Sessions = () => {
  return (
    <div style={{ maxWidth: "800px", margin: "0 auto", padding: "20px" }}>
      <h2 style={{ textAlign: "center", marginBottom: "30px" }}>Sessions</h2>
      {sessions.map((session) => (
        <div
          key={session.id}
          style={{
            border: "1px solid #ddd",
            borderRadius: "10px",
            padding: "20px",
            marginBottom: "20px",
            boxShadow: "0 2px 5px rgba(0,0,0,0.1)"
          }}
        >
          <h3>{session.title}</h3>
          <p><strong>Speaker:</strong> {session.speaker}</p>
          <p><strong>Time:</strong> {session.time}</p>
          <p><strong>Location:</strong> {session.location}</p>
        </div>
      ))}
    </div>
  );
};

export default Sessions;
