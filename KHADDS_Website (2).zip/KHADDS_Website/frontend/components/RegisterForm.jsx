import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import "./RegisterForm.css";

function RegisterForm() {
  const location = useLocation();
  const session = location.state?.session;

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    event: "",
    sessionTitle: ""
  });

  // Pre-fill event + session if passed from session page
  useEffect(() => {
    if (session) {
      setFormData((prev) => ({
        ...prev,
        event: getEventName(session.eventId),
        sessionTitle: session.title
      }));
    }
  }, [session]);

  const getEventName = (eventId) => {
    const eventMap = {
      1: "Tech Summit 2025",
      2: "Women in Computing",
      3: "Cybersecurity Workshop",
      4: "Hackathon Code for Good",
      5: "Resume Workshop",
      6: "Internship Prep",
      7: "JavaScript Crash Course"
    };
    return eventMap[eventId] || "";
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
    alert(`Registration submitted for ${formData.sessionTitle || formData.event}!`);
  };

  return (
    <div className="form-wrapper">
      <form onSubmit={handleSubmit}>
        <h2>Register {formData.sessionTitle && `for "${formData.sessionTitle}"`}</h2>

        <label>Name:</label>
        <input
          type="text"
          name="name"
          value={formData.name}
          onChange={handleChange}
          required
        />

        <label>Email:</label>
        <input
          type="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          required
        />

        <label>Event:</label>
        {session ? (
          <input type="text" name="event" value={formData.event} readOnly />
        ) : (
          <select name="event" value={formData.event} onChange={handleChange} required>
            <option value="">-- Select an Event --</option>
            <option value="Tech Summit 2025">Tech Summit 2025</option>
            <option value="Women in Computing">Women in Computing</option>
            <option value="Cybersecurity Workshop">Cybersecurity Workshop</option>
            <option value="Hackathon Code for Good">Hackathon Code for Good</option>
            <option value="Resume Workshop">Resume Workshop</option>
            <option value="Internship Prep">Internship Prep</option>
            <option value="JavaScript Crash Course">JavaScript Crash Course</option>
          </select>
        )}

        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

export default RegisterForm;
