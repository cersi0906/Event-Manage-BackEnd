<?php
include 'C:\xampp\htdocs\KHADDS_Website\backend\includes\connect.php';

if ($conn) {
    echo "Database connected successfully!";
}
?>